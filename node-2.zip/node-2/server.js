const express = require('express');

const app = express();

const PORT = 8081;

// app.use(express.json());
// app.use(express.urlencoded({extended:true}));
app.use(express.static('public'));

app.use((req, res, next) => {
    next();
})

app.get('/home', (req, res) => {
    res.sendStatus(200);
    res.send('get');
})


app.listen(PORT, (err) => {
    if(err) {
        console.error('Error at server')
    }
    console.log(`Server works at port ${PORT}`);
});
