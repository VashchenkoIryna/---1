const http = require('http');
const fs = require('fs').promises;

const PORT = 8081;

//обработчик запросв
const requireHandler = async (request, response) => {
    const mainfile = await fs.readFile('./package.json', 'utf8');
    response.writeHead(200, {'Content-type': 'text/html'});
    response.end(mainfile)
};

const server = http.createServer(requireHandler);

//Запускам сервер чтобы слушал зарезервированный порт
// -- порт по умолчанию http - 80
// -- порт по уомолчанию https - 443
server.listen(PORT, (err) => {
    if(err) {
        console.error('Error at server')
    }
    console.log(`Server works at port ${PORT}`);
});

// const PORT = 8081;

// const requireHandler = (request, response) => {
//     if (request.url.indexOf('/home') >= 0) {
//         response.writeHead(200, {'Content-Type':'text/html'});
//         response.end(
//             `<h1>Welcome to Home Page</h1>`
//         );
//          console.log(request.url)
//     }
//     response.writeHead(200, {'Content-Type':'text/html'});
//     response.end(
//         `<h1>Welcome to Other Page</h1>`
//     );
// };

// const server = http.createServer(requireHandler);
// server.listen(PORT, () => {
//     try {
//         console.log(`Server works at port ${PORT}`)
//     }catch(err) {
//         console.log('Error at server')
//     }
// })


